<?php 
$mod_strings['LBL_RLI_WON'] = 'Set open RLIs won';
$mod_strings['LBL_RLI_LOST'] = 'Set open RLIs lost';
?>
