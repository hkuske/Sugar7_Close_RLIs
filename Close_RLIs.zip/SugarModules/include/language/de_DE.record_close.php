<?php 
$mod_strings['LBL_RLI_WON'] = 'Offene RLIs gewonnen';
$mod_strings['LBL_RLI_LOST'] = 'Offene RLIs verloren';
?>
